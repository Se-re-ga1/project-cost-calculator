const { jsPDF } = window.jspdf;

function calculate() {
  const area = parseFloat(document.getElementById('area').value);
  const complexity = parseFloat(document.getElementById('complexity').value);
  const checkboxes = document.querySelectorAll('.section-checkbox:checked');

  if (isNaN(area) || area <= 0) {
    document.getElementById('result').innerHTML = 'Введите корректную площадь объекта.';
    return;
  }

  let total = 0;
  let details = '<strong>Детализация расчета:</strong><ul>';

  checkboxes.forEach(cb => {
    const base = parseFloat(cb.value);
    const name = cb.nextElementSibling.innerText;
    const cost = base + (area * 10 * complexity);
    total += cost;
    details += `<li>${name}: ${cost.toLocaleString('ru-RU')} руб.</li>`;
  });

  details += '</ul><p><strong>Итоговая стоимость: ' + total.toLocaleString('ru-RU') + ' руб.</strong></p>';
  document.getElementById('result').innerHTML = details;
}

function downloadPDF() {
  const area = document.getElementById('area').value;
  const complexityText = document.getElementById('complexity').options[document.getElementById('complexity').selectedIndex].text;
  const resultContent = document.getElementById('result').innerText;

  if (resultContent.includes('Введите корректную площадь')) {
    alert('Сначала введите корректные данные для расчета!');
    return;
  }

  const doc = new jsPDF();
  doc.setFontSize(16);
  doc.text('Расчет стоимости проектной документации', 10, 20);
  doc.setFontSize(12);
  doc.text('Площадь объекта: ' + area + ' м²', 10, 30);
  doc.text('Тип объекта: ' + complexityText, 10, 40);
  doc.setFontSize(10);
  doc.text(resultContent, 10, 50);
  doc.save('расчет_проектной_документации.pdf');
}

document.querySelectorAll('input, select').forEach(el => {
  el.addEventListener('input', calculate);
});
